<pre>
<?php

echo '<br/> var_dump()<br/>';
$a = array(1, 2, array("a","b","c"));
var_dump($a);

$b = 3.1;
$c = true;
var_dump($b, $c);

?>
</pre>

