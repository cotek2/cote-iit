Lab 4:
This lab is a page on the website with two links.
One link (RSS) is contains an HTML file of 5 rss's.
the other link (XML) contains the same information but in an XML 
format instead of an RSS format.