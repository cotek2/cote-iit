Lab 5:
file:///C:/Users/CoteKevin/Desktop/ITWS1100/iit/Lab3/Main_m.html 
In this lab we were expecteed to take a template, that had several input boxes, and have 
add a clear button that would clear the boxes when clicked.
Also I added a button called 'submit' that uses the alert function to display the first, last,
and nickname of the user if he/she entered such details.