This was a labe where we we introduseedd to Xammp and practice using it.

there was also a template that we had to change slightli to learn the workings of window.location.

code: <script>window.location.assign("http://www.rpi.edu")</script>

this line of code calls the object that is the oipen window the website is opperating on.
Then it passes a new locatio (a new web location).
It then usses assign to pass it to a spicific URL.