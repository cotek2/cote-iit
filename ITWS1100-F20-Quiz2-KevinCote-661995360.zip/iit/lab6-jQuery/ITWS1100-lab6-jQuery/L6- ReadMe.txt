Lab 6: ReadMe

In this lab their was a given template and we had to add code in the Javascript file.
In this file we had to add a function to:
1. change the title to your name 
2. make the buttons show and hide the text a a spicific pace 
3. individualy change the color of the list (text) between red and black using a given function to call
4. make the toggle button work(simular to the #2 but with no pace, and using the toggle finction)

The point of this lab was to practice using "jQuery".
