$(document).ready(function() {
    $.ajax({
    	type: "GET",
    	url: "lab9Json.js",
    	dataType: "json",
   		success: function(responseData, status){
			var output = "<ul>"; 
			$.each(responseData.items, function() {
				$("#labs").append(
				  "<a hef= '" + this.link + "' >" + this.title + "</a></br>",
				  "<a>" + this.description +  "</a></br>");
			});
			output += "</ul>";
    	}
	  });	
	  
	  
});