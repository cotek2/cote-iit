<?php

  $name='Simon';
  
  if(true) {
    echo "This will be written: Hi $name <br/>";
  }

  for($i=0; $i<10; $i++) {
    echo $i . '<br/>';
  }
?>