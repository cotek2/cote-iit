<?php

    echo '<h2>We can write out HTML too...</h2>';

   $sum = 2 + 4;
   echo 'As well as variables.  The sum is: ' . $sum . '<br/>';

   echo "Double quoted strings are parsed: $sum <br/>";
   echo 'Single quoted strings are not: $sum';
?>
