Lab 2:
This is a labe where we were intordused to HTML and used a template 
to create our own resume based off the format given in the template.