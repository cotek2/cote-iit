<?php

  function cube($val) {
    echo "This function returns the cube of $val, which is ";
    return $val * $val * $val;
  }
  echo cube(5);

?>
