$(document).ready(function() {
    $('#logbutton').click(function() {
        if ($('#logbutton').html() == "log out"){
            $('#logbutton').html("log in");
        }
        else{
            location.replace("file:///C:/xampp/htdocs/iit/iit/quiz2/login.html");
            $('#logbutton').html("log out");
        }
    });
    



});