Lab 9:
The point of this lab was to practice ajax and Json.
We were given examples and expected to remake the website using these new tequnecis.