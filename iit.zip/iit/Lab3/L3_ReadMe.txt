Lab 3:
This is a lab where we created a website based off a given template
and then we had to the the school RIS so it can be accessed via the 
internet.  I used FileZilla client to upload it to the internet.
This website has been updated severl times since.

This website is now completly broken up by pages, each link has it's own page.
