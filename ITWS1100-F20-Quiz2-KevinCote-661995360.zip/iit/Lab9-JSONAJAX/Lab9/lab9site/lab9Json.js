{
        "items": [
        {
            "title": "Lab2",
            "menuDesc": "Resume",
            "link": "7",
            "description": "A lab in which it contains a resume.",
            "image" : "http://localhost/iit/iit/Americanflag.jpg",
            "tags": ""
        },
        {
            "title": "Lab3",
            "menuDesc": "http://localhost/iit/iit/Lab3/Main_m.html",
            "link": "Main_m.html",
            "description": "A lab in which we were expected to make a website.",
            "image" : "http://localhost/iit/iit/Americanflag.jpg",
            "tags": ""
        },
        {
            "title": "Lab4",
            "menuDesc": "RSS",
            "link": "Lab 4 - Rss",
            "linkb": "http://localhost/iit/iit/Lab4/Lab%204%20-%20Rss",
            "description": "This lab was to wright a RSS file and a XML file.",
            "image" : "http://localhost/iit/iit/Americanflag.jpg",
            "tags": ""
        },
        {
            "title": "Lab4",
            "menuDesc": "XML",
            "link": "Lab 4 - XML",
            "linkb": "http://localhost/iit/iit/Lab4/Lab%204%20-xml.txt",
            "description": "This lab was to wright a RSS file and a XML file.",
            "image" : "http://localhost/iit/iit/Americanflag.jpg",
            "tags": ""
        },
        {
            "title": "Lab5",
            "menuDesc": "JavaScript",
            "link": "http://localhost/iit/iit/Lab5/ITWS1100-F20-Lab5-JavaScript/ITWS1100-F20-Lab5-JavaScript/lab5.html",
            "description": "This lab had a given template what had to be edited to add an alet call and a clear text button.",
            "image" : "http://localhost/iit/iit/Americanflag.jpg",
            "tags": ""
        },
        {
            "title": "Lab6",
            "menuDesc": "JQuery",
            "link": "http://localhost/iit/iit/lab6-jQuery/ITWS1100-lab6-jQuery/lab6.html",
            "description": "This lab was an introduction to JQuery",
            "image" : "http://localhost/iit/iit/Americanflag.jpg",
            "tags": ""
        },
        {
            "title": "Lab7",
            "menuDesc": "Prodject Mockup",
            "link": "",
            "description": "This lab was a group project that was to create a visual modle of how the RPI directory website could be updated/changed.",
            "image" : "http://localhost/iit/iit/Americanflag.jpg",
            "tags": ""
        },
        {
            "title": "Lab8",
            "menuDesc": "Xampp",
            "link": "http://localhost/iit/iit/lab8-KevinCote/ITWS1100-F20-W9C2-lab8-XAMPP/lab8/lab8.html",
            "description": "This lab was a transition lab; the perpose was to move the iit file to Xampp.",
            "image" : "http://localhost/iit/iit/Americanflag.jpg",
            "tags": ""
        },
        {
            "title": "Lab9",
            "menuDesc": "Website (update)",
            "link": "http://localhost/iit/iit/Lab9-JSONAJAX/Lab9/lab9site/lab9.html",
            "description": "This lab was updating the website.",
            "image" : "http://localhost/iit/iit/Americanflag.jpg",
            "tags": ""
        }
    ]
}