<?php

    echo 'This is a PHP block<br/>';
    echo 'Hello world!';

?>
