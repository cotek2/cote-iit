function showName(formObj) {
    alert(formObj.fname.value + ' ' + formObj.lname.value + ' ' + formObj.nname.value);
    }