<form action="PHPSlide14greet.php" method="POST">
  Name: <input type="text" name="name" value=""/>
</form>
