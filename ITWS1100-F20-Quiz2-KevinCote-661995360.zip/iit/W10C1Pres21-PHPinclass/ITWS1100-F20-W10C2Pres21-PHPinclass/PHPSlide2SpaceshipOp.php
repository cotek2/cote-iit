<pre>
  <p>Spaceship operator <=>

<?php

// This will only work in PHP7.1+
$a=1;
$b=2;
echo "$a<=>$b == ";
echo $a<=>$b;
echo '<br/>';

$a=1;
$b=1;
echo "$a<=>$b == ";
echo $a<=>$b;
echo '<br/>';

$a=2;
$b=1;
echo "$a<=>$b == ";
echo $a<=>$b;
echo '<br/>';
?>
</pre>
