Test 1, ReadMe:


I reformated my website so that all the labes would have their own page;
this included making 4 new paged, and reformatting the pages page.
file:///C:/Users/CoteKevin/Pictures/diagram.pdf
^ (that is a link to a PDF of the diagram)

