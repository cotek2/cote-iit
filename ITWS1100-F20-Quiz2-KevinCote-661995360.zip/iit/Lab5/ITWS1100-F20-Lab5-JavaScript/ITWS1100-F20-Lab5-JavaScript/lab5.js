/* Lab 5 JavaScript File 
   Place variables and functions in this file */

function validate(formObj) {
   // put your validation code here
   // it will be a series of if statements

   if (formObj.firstName.value == "") {
      alert("You must enter a first name");
      formObj.firstName.focus();
      return false;
   }
   
      return true;
   }
   

function showName() {
     let firstname = document.getElementById('firstName').value;
     let lastname = document.getElementById('lastName').value;
     let nickname = document.getElementById('pseudonym').value;
     alert(firstname + ' ' + lastname + ' ' + 'is' + nickname);
}
function Clear(){
   document.getElementById('firstName').value = ''
   document.getElementById('lastName').value = ''
   document.getElementById('title').value = ''
   document.getElementById('org').value = ''
   document.getElementById('pseudonym').value = ''
   document.getElementById('comments').value = ''
}
