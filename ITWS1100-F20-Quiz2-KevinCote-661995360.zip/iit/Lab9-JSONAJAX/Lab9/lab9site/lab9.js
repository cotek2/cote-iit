$(document).ready(function() {
	var pp = document.referrer;
	if (pp == "http://localhost/iit/iit/Lab9-JSONAJAX/Lab9/lab9site/login.html"){
		$('#logbutton').html("log out");
	}
	
    $.ajax({
    	type: "GET",
    	url: "lab9Json.js",
    	dataType: "json",
   		success: function(responseData, status){
			var output = "<ul>"; 
			$.each(responseData.items, function() {
				$("#labs").append(
				  "<a hef= '" + this.link + "' >" + this.title + "</a></br>",
				  "<a>" + this.description +  "</a></br>");
			});
			output += "</ul>";
    	}
	  });	
	

	  $('#logbutton').click(function() {
        if ($('#logbutton').html() == "log out"){
            $('#logbutton').html("log in");
        }
        else{
			$('#logbutton').html("log out");
            location.replace("http://localhost/iit/iit/Lab9-JSONAJAX/Lab9/lab9site/login.html");
        }
	});
	$('#submit').click(function() {
		let line1 = document.getElementById('firstName').value;
		let line2 = document.getElementById('lastName').value;
	 
	$.ajax({
		type: "GET",
		url: "http://localhost/iit/iit/quiz2/usersXML.xml",
		dataType: "xml",
		success: function(responseData, status){
			//alert("h");
			$(responseData).find("item").each(function() {
				//alert($(this).find("userid").text() == line1);
				  if($(this).find("userid").text() == line1){
					if($(this).find("password").text() == line2){
						val = 1
						location.replace("http://localhost/iit/iit/Lab9-JSONAJAX/Lab9/lab9site/lab9.html");
						$('#logbutton').html("log out");

					}
				  }
				  else{
					  alert("invalid username or password")
					  location.replace("http://localhost/iit/");
				  }
			
		})


		}
}); 
}); 
});