$(document).ready(function() {
    xml = new XMLHttpRequest();
    xml.open("usersXML.xml")
    var x = xml.getElementsBy("note");
    
    $('button').click(function() {
        
        let user = document.getElementById('firstName').value;
        let password = document.getElementById('lastName').value;
        alert(x)
    });
    
});